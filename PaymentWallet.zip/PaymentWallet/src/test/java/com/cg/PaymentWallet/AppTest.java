package com.cg.PaymentWallet;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.TreeMap;

import org.junit.Test;

import com.cg.paymentwallet.bean.Customer;
import com.cg.paymentwallet.bean.Wallet;
import com.cg.paymentwallet.exception.WalletException;
import com.cg.paymentwallet.service.IWalletService;
import com.cg.paymentwallet.service.WalletServiceImpl;

public class AppTest {
	
	
	public static IWalletService iWalletService=new WalletServiceImpl();
	
    
	@Test
	public void addCustomerTestEquals() throws WalletException
	{
		Customer customer1 = new Customer("9176042782","Krish","Krish@9896","krish9896@gmail.com",new Wallet(),new TreeMap<LocalDateTime, String>());
		assertEquals("9176042782",iWalletService.addCustomer(customer1));
			
	}
    @Test
  	public void addCustomerTestNotEquals() throws WalletException
  	{

  		Customer customer5 = new Customer("9959102405","Briseis","Briseis@9896","briseis9896@gmail.com",new Wallet(),new TreeMap<LocalDateTime, String>());
  		assertNotEquals("56968621",iWalletService.addCustomer(customer5));
  		
  	}
	

	@Test
	public void intialBalanceTestEquals() throws WalletException
	{
		Customer customer6 = new Customer("9176052782","Krish","Krish@9896","krish9896@gmail.com",new Wallet(),new TreeMap<LocalDateTime, String>());
		iWalletService.addCustomer(customer6);
		assertEquals(BigDecimal.valueOf(0.0),customer6.getWallet().getBalance());
		
	}
	
	@Test
	public void depositMoneyTestEquals() throws WalletException
	{
		Customer customer2 = new Customer("9959101405","Briseis","Briseis@9896","briseis9896@gmail.com",new Wallet(),new TreeMap<LocalDateTime, String>());
		iWalletService.addCustomer(customer2);
		iWalletService.deposit(customer2, BigDecimal.valueOf(8500.00));
		Customer result = iWalletService.showBalance("9959101405", "Briseis@9896");
		assertEquals(BigDecimal.valueOf(8500.00),result.getWallet().getBalance());
	}
	@Test
	public void withdrawMoneyTestTrue() throws WalletException
	{
		Customer customer3 = new Customer("9959001405","Briseis","Briseis@9896","briseis9896@gmail.com",new Wallet(),new TreeMap<LocalDateTime, String>());
		iWalletService.addCustomer(customer3);
		iWalletService.deposit(customer3, BigDecimal.valueOf(8500.00));
		assertTrue(iWalletService.withDraw(customer3, BigDecimal.valueOf(3000.00)));
	}

	
	@Test(expected = WalletException.class)
	public void withdrawMoneyTestFalse() throws WalletException
	{
		Customer customer4 = new Customer("9959101405","Briseis","Briseis@9896","briseis9896@gmail.com",new Wallet(),new TreeMap<LocalDateTime, String>());
		iWalletService.addCustomer(customer4);
		iWalletService.deposit(customer4, BigDecimal.valueOf(8500.00));
		assertFalse(iWalletService.withDraw(customer4, BigDecimal.valueOf(9000.00)));
	}

}

