package com.cg.paymentwallet.exception;

@SuppressWarnings("serial")
public class WalletException extends Exception {
public WalletException(String msg) {
	super(msg);
}
}
